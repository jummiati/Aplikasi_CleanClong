package com.example.uastekber;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class CarWash extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_car_wash);

        ImageButton btnMove = findViewById(R.id.Btnhome);
        btnMove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                moveToHome();
            }
        });

        btnMove = findViewById(R.id.BtnBack);
        btnMove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                moveToHome();
            }
        });

        btnMove = findViewById(R.id.BtnOrder);
        btnMove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                moveToOrder();
            }
        });

        btnMove = findViewById(R.id.BtnInbox);
        btnMove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                moveToInbox();
            }
        });

        btnMove = findViewById(R.id.BtnProfile);
        btnMove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                moveToProfile();
            }
        });

        Button BtnMove = findViewById(R.id.BtnPesan);
        BtnMove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                moveToOrder();
            }
        });
    }

    private void moveToProfile() {
        Intent intent = new Intent(CarWash.this,Profil.class);
        startActivity(intent);
    }

    private void moveToInbox() {
        Intent intent = new Intent(CarWash.this,Inbox.class);
        startActivity(intent);
    }

    private void moveToOrder() {
        Intent intent = new Intent(CarWash.this,Order.class);
        startActivity(intent);
    }

    private void moveToHome() {
        Intent intent = new Intent(CarWash.this,home.class);
        startActivity(intent);
    }
}
