package com.example.uastekber;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class Profil extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profil);

        ImageButton btnMove = findViewById(R.id.Btnhome);
        btnMove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                moveToHome();
            }
        });

        btnMove = findViewById(R.id.BtnBack);
        btnMove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                moveToHome();
            }
        });

        btnMove = findViewById(R.id.BtnOrder);
        btnMove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                moveToOrder();
            }
        });

        btnMove = findViewById(R.id.BtnInbox);
        btnMove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                moveToInbox();
            }
        });

        btnMove = findViewById(R.id.BtnProfile);
        btnMove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                moveToProfile();
            }
        });

       Button BtnMove = findViewById(R.id.BtnTentang);
        BtnMove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                moveToTentang();
            }
        });

        BtnMove = findViewById(R.id.BtnKeluar);
        BtnMove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                moveToMainActivity();
            }
        });

        BtnMove = findViewById(R.id.BtnKontak);
        BtnMove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                moveToKontak();
            }
        });

    }

    private void moveToKontak() {
        Intent intent = new Intent(Profil.this,Kontak.class);
        startActivity(intent);
    }

    private void moveToMainActivity() {
        Intent intent = new Intent(Profil.this,MainActivity.class);
        startActivity(intent);
    }

    private void moveToTentang() {
        Intent intent = new Intent(Profil.this,Tentang.class);
        startActivity(intent);
    }

    private void moveToProfile() {
        Intent intent = new Intent(Profil.this,Profil.class);
        startActivity(intent);
    }

    private void moveToInbox() {
        Intent intent = new Intent(Profil.this,Inbox.class);
        startActivity(intent);
    }

    private void moveToOrder() {
        Intent intent = new Intent(Profil.this,Order.class);
        startActivity(intent);
    }

    private void moveToHome() {
        Intent intent = new Intent(Profil.this,home.class);
        startActivity(intent);
    }
}
