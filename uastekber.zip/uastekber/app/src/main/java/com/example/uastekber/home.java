package com.example.uastekber;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class home extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        ImageButton btnMove = findViewById(R.id.BtnCarPolish);
        btnMove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                moveToCarPolish();
            }
        });

        btnMove = findViewById(R.id.BtnCarWash);
        btnMove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                moveToCarWash();
            }
        });

        btnMove = findViewById(R.id.Btnhome);
        btnMove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                moveToHome();
            }
        });

        btnMove = findViewById(R.id.BtnOrder);
        btnMove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                moveToOrder();
            }
        });

        btnMove = findViewById(R.id.BtnInbox);
        btnMove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                moveToInbox();
            }
        });

        btnMove = findViewById(R.id.BtnProfile);
        btnMove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                moveToProfile();
            }
        });


    }

    private void moveToProfile() {
        Intent intent = new Intent(home.this,Profil.class);
        startActivity(intent);
    }

    private void moveToInbox() {
        Intent intent = new Intent(home.this,Inbox.class);
        startActivity(intent);
    }

    private void moveToOrder() {
        Intent intent = new Intent(home.this,Order.class);
        startActivity(intent);
    }

    private void moveToHome() {
        Intent intent = new Intent(home.this,home.class);
        startActivity(intent);
    }

    private void moveToCarWash() {
        Intent intent = new Intent(home.this,CarWash.class);
        startActivity(intent);
    }

    private void moveToCarPolish() {
        Intent intent = new Intent(home.this,CarPolish.class);
        startActivity(intent);
    }
}
